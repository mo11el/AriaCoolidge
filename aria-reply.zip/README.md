# AriaReply

Aria is an AI reminder assistant you text at a Telnyx phone number. The backend accepts incoming SMS webhooks, sends the message to an LLM to parse intent/time, stores a one-off reminder, and schedules a message at the due time.
