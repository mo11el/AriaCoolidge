// Telnyx SMS handler stub
import axios from 'axios';
export async function handleIncoming(payload) {
  console.log('Incoming:', payload);
}
